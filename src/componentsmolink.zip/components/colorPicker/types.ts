export interface ColorPickerProps {
  color: string;
  onChangeMethod: () => void;
  handleChangeComplete: () => void;
}
