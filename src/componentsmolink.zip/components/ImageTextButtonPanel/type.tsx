export interface ImageTextButtonPanelTypes {
  img: string;
  content1: string;
  content2: string;
  content3: string;
  imgheight: string;
  imgwidth: string;
  URL?: string;
}
