import React from 'react';

import ProcessingGrid from '.';

export default {
  component: ProcessingGrid,
  title: 'ProcessingGrid',
  tags: ['ProcessingGrid'],
};
export const Default = () => <ProcessingGrid />;
