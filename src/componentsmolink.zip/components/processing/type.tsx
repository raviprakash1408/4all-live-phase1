export interface ProcessingType {
  // name: 'string';
  // height: 'string';
  // width: 'string';
  backgroundColor: string;
}
