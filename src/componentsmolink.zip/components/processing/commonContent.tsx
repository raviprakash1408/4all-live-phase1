import React from 'react';

const CommonContent = () => {
  return (
    <div>
      {' '}
      <div className="flex flex-col">
        <div className="mt-4 flex">
          <div className="mr-4 mt-2">
            <img src="/assets/icons/icon1.svg" alt="no icon" />
          </div>
          <p className="mr-12 text-quaternary-color">
            Storage:23% <span className="ml-4">230GB/1TB</span>
          </p>
        </div>
        <div className="mt-2 flex">
          <div className="mr-4">
            <img src="/assets/icons/icon8.svg" alt="no icon" />
          </div>
          <p className=" mr-6 text-quaternary-color">CPU:16%</p>
          <div className="mr-2 mt-2">
            <img src="/assets/icons/g2076.svg" alt=" no icon" />
          </div>
          <p className="mr-12 text-quaternary-color">RAM:2%</p>
        </div>
        <div className="mr-2 mt-2 flex">
          <div>
            <img src="/assets/icons/Group 978.svg" alt="no icon" />
          </div>
          <p className=" ml-4 text-quaternary-color">Bitrate:</p>
          <div className="ml-1 mt-2">
            <img src="/assets/icons/icon6.svg" alt="no icon" />
          </div>
          <p className=" text-quaternary-color">500 kbps</p>
          <div className="ml-1 mt-2">
            <img src="/assets/icons/icon4.svg" alt="no icon" />
          </div>
          <p className="text-quaternary-color">3233 kbps</p>
        </div>
        <div className="mt-2 flex">
          <div className="mr-5">
            <img src="/assets/icons/Group 581308.svg" alt="no icon" />
          </div>
          <p className="mr-24 text-quaternary-color">
            IP:<span className="ml-1">192.168.11.111</span>
          </p>
        </div>
        <div className="mt-2 flex">
          <div className="mr-4">
            <img src="/assets/icons/g172.svg" alt="no icon" />
          </div>
          <p className="mr-12 text-quaternary-color">
            Firmware version: 1.01.06
          </p>
        </div>
      </div>
    </div>
  );
};

export default CommonContent;
