import React, { useState } from 'react';

import { SettingsComponent } from '../halfcurvedbuttons';
import CommonContent from './commonContent';

const ProcessingGrid = () => {
  const [type, setType] = useState('status');
  return (
    <div>
      {type === 'status' && (
        <div
          className={`flex  h-80  w-[19.5rem] rounded-2xl border-2 border-quaternary-color bg-primary-color p-4 `}
        >
          <div>
            <div className="flex flex-col items-center">
              <button
                type="button"
                onClick={() => {
                  setType('calculating');
                }}
                className="text-lg"
              >
                <SettingsComponent
                  content="Start speed test"
                  height="h-10"
                  width="w-56"
                  backgroundColor="bg-tertiary-color"
                  image="/assets/MoLink/Status.svg"
                  textcolor="text-quaternary-color"
                />
              </button>

              {/* <h1 className="mt-2 text-lg text-secondary-color">Processing</h1> */}
              <p className=" text-center text-quaternary-color">
                Please run your first speed test
              </p>
              <hr className=" mt-2 w-full border border-tertiary-color" />

              <CommonContent />
            </div>
          </div>
        </div>
      )}
      {type === 'calculating' && (
        <div
          className={`flex  h-96  w-80 rounded-2xl border-2 border-quaternary-color bg-tertiary-color p-4 `}
        >
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => {
                setType('finished');
              }}
              className=""
            >
              <SettingsComponent
                content="Calculating speed test"
                height="h-10"
                width="w-60"
                backgroundColor="bg-primary-color"
                image="/assets/MoLink/Status.svg"
                textcolor="text-quaternary-color"
              />
            </button>
            <div className="mt-2 animate-spin">
              <img src="/assets/icons/icon7.svg" alt="no icon" className="" />
            </div>
            <h1 className="mt-2 text-lg text-secondary-color">Processing</h1>
            <p className=" text-center text-quaternary-color">
              Hold on,we are calculating your connectivity result.
            </p>
            <CommonContent />
          </div>
        </div>
      )}
      {type === 'finished' && (
        <div
          className={`flex  h-96  w-[19.5rem] rounded-2xl border-2 border-quaternary-color bg-primary-color p-4 `}
        >
          <div>
            <div className="flex flex-col items-center">
              <button
                type="button"
                onClick={() => {
                  setType('status');
                }}
                className="text-lg"
              >
                <SettingsComponent
                  content="Start speed test"
                  height="h-10"
                  width="w-56"
                  backgroundColor="bg-tertiary-color"
                  image="/assets/MoLink/Status.svg"
                  textcolor="text-quaternary-color"
                />
              </button>

              {/* <h1 className="mt-2 text-lg text-secondary-color">Processing</h1> */}
              <p className=" text-center text-quaternary-color">
                Last tested 06/05/2023 2:28 PM
              </p>
              <div className="mt-2  flex">
                <img
                  src="/assets/icons/Download.svg"
                  alt=""
                  className="mr-2 h-5 w-5"
                />
                <p className="mr-24 text-quaternary-color">
                  Download:<span className="ml-1">92.98Mbps</span>
                </p>
              </div>
              <div className="mr-[15px] mt-1 flex">
                <img
                  src="/assets/icons/Download.svg"
                  alt=""
                  className="mr-2 h-5 w-5 rotate-180"
                />
                <p className="mr-24 text-quaternary-color">
                  Upload:<span className="ml-1">93.54Mbps</span>
                </p>
              </div>
              <div className="mr-8 mt-1 flex flex-row">
                <img
                  src="/assets/icons/Latency.svg"
                  alt=""
                  className="mr-2 h-5 w-5"
                />
                <p className="mr-20 text-quaternary-color">
                  Latency:<span className="ml-1">110.08 ms</span>
                </p>
              </div>
              <div className="mr-8 mt-1 flex">
                <img
                  src="/assets/icons/PacketLoss.svg"
                  alt=""
                  className="mr-2 h-5 w-5"
                />
                <p className="mr-24 text-quaternary-color">
                  Packet loss:<span className="ml-1">0.0%</span>
                </p>
              </div>
              <hr className="mt-2 w-full border border-tertiary-color" />

              <CommonContent />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default ProcessingGrid;
