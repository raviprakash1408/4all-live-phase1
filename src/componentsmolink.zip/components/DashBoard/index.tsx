import React from 'react';

import DashBoard1 from './dashBoard1';

const DashBoardIndex = () => {
  return (
    <div>
      <DashBoard1 />
      <div className="flex">
        <div className=" relative pl-5 pt-10">
          <img
            src="/assets/images/spaceship.png"
            alt=""
            className="h-40 w-80"
          />
          <img
            src="/assets/icons/Zoomout.svg"
            alt=""
            className=" absolute bottom-1 left-[19.2rem] w-6 rounded-sm bg-[#21464F] p-1"
          />
          <div className=" absolute top-12 ml-1 flex w-36 rounded-md bg-tertiary-color">
            <img
              src="/assets/icons/Video.svg"
              className="ml-2 mt-1 h-3"
              alt=""
            />
            <div className=" ml-2 flex rounded-xl text-xs text-white">
              Camera 01{' '}
              <span className="ml-2 text-xs text-[#70A6A6]">Hanger</span>{' '}
            </div>
          </div>
        </div>
        <div className=" relative pl-5 pt-10">
          <img
            src="/assets/images/spaceship.png"
            alt=""
            className="h-40 w-80"
          />
          <img
            src="/assets/icons/Zoomout.svg"
            alt=""
            className=" absolute bottom-1 left-[19.2rem] w-6 rounded-sm bg-[#21464F] p-1"
          />
          <div className=" absolute top-12 ml-1 flex w-36 rounded-md bg-tertiary-color">
            <img
              src="/assets/icons/Video.svg"
              className="ml-2 mt-1 h-3"
              alt=""
            />
            <div className=" ml-2 flex rounded-xl text-xs text-white">
              Camera 01{' '}
              <span className="ml-2 text-xs text-[#70A6A6]">Hanger</span>{' '}
            </div>
          </div>
        </div>
        <div className=" relative pl-5 pt-10">
          <img
            src="/assets/images/spaceship.png"
            alt=""
            className="h-40 w-80"
          />
          <img
            src="/assets/icons/Zoomout.svg"
            alt=""
            className=" absolute bottom-1 left-[19.2rem] w-6 rounded-sm bg-[#21464F] p-1"
          />
          <div className=" absolute top-12 ml-1 flex w-36 rounded-md bg-tertiary-color">
            <img
              src="/assets/icons/Video.svg"
              className="ml-2 mt-1 h-3"
              alt=""
            />
            <div className=" ml-2 flex rounded-xl text-xs text-white">
              Camera 01{' '}
              <span className="ml-2 text-xs text-[#70A6A6]">Hanger</span>{' '}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashBoardIndex;
