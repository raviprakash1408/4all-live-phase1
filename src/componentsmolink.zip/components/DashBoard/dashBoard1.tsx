import React from 'react';

import RangeSlider from '../range';
import WithoutProgress from '../range/withoutProgress';

const DashBoard1 = () => {
  return (
    <div>
      <div className="flex pl-5 ">
        <div
          // CPU BUTTON
          className="mt-1 flex h-10 w-[7.5rem] items-center rounded-l-2xl border-2 border-primary-color bg-fifth-color p-2  text-tertiary-color hover:border-quaternary-color"
        >
          <img
            src="/assets/icons/CPU_Load.svg"
            alt="Icon"
            className="ml-1 h-4 "
          />
          <p className="ml-4 flex text-xs font-semibold text-quaternary-color">
            CPU Load
          </p>
        </div>

        <div>
          <div
            // type="button"
            className={`mt-1 flex h-10 w-[7.5rem] items-center rounded-r-2xl border-2 border-primary-color bg-tertiary-color py-2 `}
          >
            {/* <img src={props.img} alt="Icon" className={``} /> */}
            {/* <p className='pl-5 font-semibold text-quaternary-color text-lg'>80%</p> */}
            {/* <p className="ml-4 text-sm flex font-semibold text-quaternary-color">{props.title}</p> */}
            <div className="ml-3 flex items-center">
              <RangeSlider
                progress={80}
                type="withoutThumb"
                width="w-12"
                textSide="left"
                dataType="%"
              />
            </div>
          </div>
        </div>

        <div>
          <div className="relative pl-3">
            <div
              // "GPU   button"
              className="mt-1 flex h-10 w-[7.5rem] items-center rounded-l-2xl border-2 border-primary-color bg-fifth-color px-1  py-2 text-tertiary-color hover:border-quaternary-color"
            >
              <img
                src="/assets/icons/GPU_Load.svg"
                alt="Icon"
                className="ml-2 h-4"
              />
              <p className="ml-4 flex text-xs font-semibold text-quaternary-color">
                GPU Load
              </p>
            </div>
          </div>
        </div>

        <div>
          <div
            // type="button"
            className="relative mt-1 flex h-10 w-[7.5rem] items-center rounded-r-2xl border-2 border-primary-color bg-tertiary-color py-2 "
          >
            <div>
              <span className="absolute -mt-4 ml-1 text-xs font-semibold text-secondary-color">
                Enc
              </span>
              <div className="absolute -top-2  ml-7 ">
                <RangeSlider
                  progress={20}
                  type="withoutThumb"
                  width="w-12"
                  textSide="left"
                  dataType="%"
                />
              </div>
            </div>

            <div className="">
              <span className="absolute ml-1 mr-40 text-xs font-semibold text-secondary-color">
                Dec
              </span>
              <div className="absolute top-1 mt-2 pl-7">
                <RangeSlider
                  progress={30}
                  type="withoutThumb"
                  width="w-12"
                  textSide="left"
                  dataType="%"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex">
          <div className="pl-3">
            <div className="mt-1 flex h-10 w-[7.5rem] items-center rounded-l-2xl border-2 border-primary-color bg-fifth-color px-1  py-2 text-tertiary-color hover:border-quaternary-color">
              <img
                src="/assets/icons/Storage.svg"
                alt="Icon"
                className="ml-2 h-4"
              />
              <p className="ml-4 flex text-xs font-semibold text-quaternary-color">
                Storage
              </p>
            </div>
          </div>

          <div
            className={`mt-1 flex h-10 w-[7.5rem] items-center rounded-r-2xl border-2 border-primary-color bg-tertiary-color py-2 `}
          >
            <div className="flex items-center justify-center">
              <span className="absolute top-[5.9rem] ml-2 text-sm text-secondary-color">
                330 GB
              </span>
              <span className="ml-2 mt-4 text-xs text-[#70A6A6]">500 GB</span>
            </div>
            <WithoutProgress
              progress={70}
              type="withoutThumb"
              width="w-12"
              textSide="left"
              dataType=""
            />
          </div>
        </div>

        <div className="pl-3">
          <div className="mt-1 flex h-10 w-[7.5rem] items-center rounded-l-2xl border-2 border-primary-color bg-fifth-color px-1  py-2 text-tertiary-color hover:border-quaternary-color">
            <img
              src="/assets/icons/Clock.svg"
              alt="Icon"
              className="ml-2 h-4"
            />
            <p className="ml-4 flex text-xs font-semibold text-quaternary-color">
              Uptime
            </p>
          </div>
        </div>

        <div
          // type="button"
          className={`mt-1 flex h-10 w-[7.7rem] items-center rounded-r-2xl border-2 border-primary-color bg-tertiary-color py-2 `}
        >
          <div className="">
            <p className="pl-2 text-sm text-quaternary-color ">
              01 d 02 h 07 min{' '}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashBoard1;
