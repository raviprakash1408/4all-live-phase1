export interface Dashboard {
  title: string;
  img: string;
  width?: string;
  height?: string;
  borderLeft?: string;
  borderRight?: string;
  border?: string;
  data?: string[] | number[];
  arrowBottom?: string;
  // subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  // backgroundColor: string;
  // rotate: string;
  // width: string;
}
