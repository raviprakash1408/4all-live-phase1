export interface FolderSpace {
  Background: string;
  img: string;
  content: string;
  height: string;
  width: string;
}
