export interface LanguageTypes {
  id?: number;
  img?: string;
  Language?: string;
  LanguageCode?: string;
  position?: string;
}
