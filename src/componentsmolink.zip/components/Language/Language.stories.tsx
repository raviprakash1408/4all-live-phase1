import LanguageSelect from '.';

export default {
  component: LanguageSelect,
  title: 'LanguageSelect',
  tags: ['LanguageSelect'],
};

export const Default = () => <LanguageSelect position="" />;
