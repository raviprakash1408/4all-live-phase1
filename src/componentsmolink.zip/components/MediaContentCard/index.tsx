'use client';

import React, { useState } from 'react';

import FileButton from './button';

const MediaContentCard = () => {
  const [hidden, setHidden] = useState(0);
  const fileData = [
    {
      id: 1,
      img: '/assets/icons/Media.svg',
      fileName: ' Production commercial.mp4',
      fileSize: 'Size:12MB',
      MainImg: '/assets/images/Image1.png',
    },
    {
      id: 2,
      img: '/assets/icons/Media.svg',
      fileName: ' Production commercial.mp4',
      fileSize: 'Size:12MB',
      MainImg: '/assets/images/Image1.png',
    },
    {
      id: 3,
      img: '/assets/icons/Media.svg',
      fileName: ' Production commercial.mp4',
      fileSize: 'Size:12MB',
      MainImg: '/assets/images/Image1.png',
    },
    {
      id: 4,
      img: '/assets/icons/Media.svg',
      fileName: ' Production commercial.mp4',
      fileSize: 'Size:12MB',
      MainImg: '/assets/images/Image1.png',
    },
  ];
  const buttonName = [
    {
      id: 1,
      buttonName: 'Roto',
    },
    {
      id: 2,
      buttonName: 'QC',
    },
    {
      id: 3,
      buttonName: 'Plate',
    },
  ];
  const Visible = (id: number) => {
    setHidden(id);
  };
  const Hidden1 = () => {
    setHidden(0);
  };
  return (
    <div>
      <section className="ml-6 mt-10 bg-[#21464F]">
        <div className="container">
          <div className="-mx-4 grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {fileData.map((item) => (
              <div key={item.id} className="group w-[95%]">
                <div className="relative mb-10 cursor-pointer overflow-hidden rounded-3xl border-2 border-primary-color duration-300 group-hover:border-secondary-color">
                  <img
                    src={item.MainImg}
                    alt=""
                    className=" h-44 w-full"
                    onMouseEnter={() => Visible(item.id)}
                    onMouseLeave={Hidden1}
                  />
                  {hidden === item.id && (
                    <img
                      src="/assets/icons/Tick.svg"
                      alt=""
                      className={` absolute top-4 ml-4  cursor-pointer rounded-full`}
                      onMouseEnter={() => Visible(item.id)}
                    />
                  )}

                  <div className="flex h-24 text-center">
                    <div className=" w-12 cursor-pointer bg-fifth-color">
                      <img
                        src={item.img}
                        alt=""
                        className="secondary-color-filter ml-3 mt-8"
                      />
                    </div>
                    <div className=" bg-primary-color min-[320px]:w-full sm:w-full md:w-full xl:w-[88%]">
                      <div className="flex flex-col">
                        <span className="ml-[19px] mt-1 text-start text-lg font-semibold text-quaternary-color group-hover:text-font-color">
                          {item.fileName}
                        </span>
                        <span className="ml-5 mt-[-5px] text-start text-sm text-quaternary-color group-hover:text-font-color">
                          {item.fileSize}
                        </span>
                        <div className="ml-2 grid grid-cols-5 pr-5">
                          {buttonName.map((itemName) => (
                            <FileButton
                              key={itemName.id}
                              name={itemName.buttonName}
                              // bgColor="bg-secondary-color"
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default MediaContentCard;
