export interface ButtonType {
  // id: number;
  name: string;
  // price: number;
  // button_text: string;
  // img: string;
  // bgColor: string;
}
