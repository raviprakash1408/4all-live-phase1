'use client';

import Image from 'next/image';
import { useSelectedLayoutSegment } from 'next/navigation';
import { useEffect, useState } from 'react';

import { ProfilePop } from '@/components';

export default function Header() {
  const segment = useSelectedLayoutSegment();

  const [animate, setAnimate] = useState<boolean>(false);
  const [currentPageTitle, setcurrentPageTitle] = useState<string>('');
  const [currentPageImage, setcurrentPageImage] = useState<string>('');

  useEffect(() => {
    setAnimate(true);
    switch (segment) {
      case 'spaces':
        setcurrentPageTitle('Spaces');
        setcurrentPageImage('/assets/sidebar/spaces.svg');
        break;
      case 'teams':
        setcurrentPageTitle('Teams & Roles');
        setcurrentPageImage('/assets/sidebar/team.svg');
        break;
      case 'statistics':
        setcurrentPageTitle('Statistics');
        setcurrentPageImage('/assets/sidebar/statistics.svg');
        break;
      case 'subscriptions':
        setcurrentPageTitle('Subscriptions');
        setcurrentPageImage('/assets/sidebar/subscriptions.svg');
        break;
      case 'billing':
        setcurrentPageTitle('Billing');
        setcurrentPageImage('/assets/sidebar/billing.svg');
        break;
      case 'support':
        setcurrentPageTitle('Support');
        setcurrentPageImage('/assets/sidebar/support.svg');
        break;
      case 'affiliate':
        setcurrentPageTitle('Affiliate');
        setcurrentPageImage('/assets/sidebar/affiliate.svg');
        break;
      case 'account':
        setcurrentPageTitle('Account');
        setcurrentPageImage('/assets/sidebar/account.svg');
        break;
      case 'knowledge':
        setcurrentPageTitle('Knowledge');
        setcurrentPageImage('/assets/sidebar/knowledge.svg');
        break;
      default:
        break;
    }

    const timeout = setTimeout(() => {
      setAnimate(false);
      clearTimeout(timeout);
    }, 1000);
  }, [segment]);

  return (
    <header>
      <div className="relative pb-2.5 pt-4">
        {currentPageTitle !== '' && currentPageImage !== '' && (
          <div
            className={`flex h-16 items-center justify-center ${
              animate ? 'fadeInDownAnimation' : ''
            }`}
          >
            <Image
              className="object-cover"
              src={currentPageImage}
              alt="header-space"
              width={24}
              height={24}
            />
            <h3 className="pl-2 text-lg text-font-color">{currentPageTitle}</h3>
          </div>
        )}
        <ProfilePop />
      </div>

      <hr className=" w-full border-[1px] border-tertiary-color" />
    </header>
  );
}
