export interface NumberType {
  name: string;
  img: string;
  subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  placeholder?: string;
  imgCursor?: string;
}
