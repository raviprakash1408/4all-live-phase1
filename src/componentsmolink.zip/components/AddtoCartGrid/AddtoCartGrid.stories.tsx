import AddtoCartGrid from '.';

export default {
  component: AddtoCartGrid,
  title: 'AddtoCartGrid ',
  tags: ['AddtoCartGrid '],
};

export const Default = () => <AddtoCartGrid />;
