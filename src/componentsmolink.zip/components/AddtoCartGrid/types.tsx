export interface HardwareTypes {
  // name: string;
  price: number;
  // img: string;
  // subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  // backgroundColor: string;
}
