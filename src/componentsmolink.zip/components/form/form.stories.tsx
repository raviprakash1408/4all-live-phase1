import Form from '.';

export default {
  component: Form,
  title: 'Form',
  tags: ['Form'],
};

export const Default = () => <Form />;
