import IconComponentButton from '.';

export default {
  component: IconComponentButton,
  title: 'IconComponentButton',
  tags: ['IconComponentButton'],
};

export const Default = () => <IconComponentButton />;
