// use client

import React from 'react';

import RangeSlider from '../range';

const IconComponentButton = () => {
  return (
    <div>
      <button
        type="button"
        className="flex items-center rounded-full border-2 border-[#21464F] bg-[#21464F] px-4 py-2 text-[#70A6A6] hover:border-quaternary-color"
      >
        <img src="/assets/icons/Grid.svg" alt="" className="h-4" />
        <span className="ml-3 text-sm">Grid size</span>
        <div className="ml-2">
          <RangeSlider
            type="withThumb"
            width="w-20"
            textSide=""
            dataType=""
            progress={10}
          />
        </div>
      </button>
    </div>
  );
};
export default IconComponentButton;
