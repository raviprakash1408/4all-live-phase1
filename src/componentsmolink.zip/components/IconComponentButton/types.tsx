export interface LTRbuttonTypes {
  progress?: number;
  type: string;
  width: string;
  textSide: string;
  dataType: string;
}
