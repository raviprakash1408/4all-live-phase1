export interface PasswordType {
  name: string;
  img: string;
  subImage?: string;
  type: 'normal' | 'all';
  value?: string;
}
