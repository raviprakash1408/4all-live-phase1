'use client';

import { useState } from 'react';

import type { InputItem } from './types';

const InputField = (props: InputItem) => {
  const [inputValue, setInputValue] = useState(props.value);
  const [touched, setTouched] = useState(false);

  const handleChange = (event: any) => {
    const { value } = event.target;
    setInputValue(value);
    // setTouched(value === '');
    setTouched(value === '' && (props.validation || false));

    if (props.onChange) {
      props.onChange(value);
    }
  };

  const handleBlur = () => {
    // setTouched(inputValue === '');
    setTouched(inputValue === '' && props.validation);
  };

  return (
    <div>
      <div className="relative flex h-11 flex-col">
        <span className="pointer-events-none absolute bottom-8 ml-4 flex-1  bg-primary-color p-1 text-sm  text-quaternary-color">
          {props.name}
        </span>
        <input
          data-testid="inputField"
          value={inputValue}
          onBlur={props.validation ? handleBlur : undefined}
          onChange={handleChange}
          type="text"
          className={`flex-1 rounded-full border-2 border-solid  text-sm ${
            touched ? `${props.errorBorder}` : 'border-tertiary-color'
          } bg-primary-color ${
            props.img === '' ? 'pl-4' : 'pl-12'
          } pr-2 font-thin text-font-color transition-colors  duration-300 ease-in-out placeholder:text-quaternary-color  ${
            touched
              ? `hover:${props.errorBorder}`
              : 'hover:border-quaternary-color'
          } focus:outline-none`}
          placeholder={props.placeholder}
        />
        {props.img !== '' && (
          <img
            src={props.img}
            className={`absolute ml-4 mt-[10px] h-6 w-6 ${props.imgCursor}`}
            alt=""
          />
        )}

        <div className="absolute top-11">
          {touched && <span className="ml-5  text-red-500">{props.error}</span>}
        </div>
      </div>
    </div>
  );
};

export default InputField;
