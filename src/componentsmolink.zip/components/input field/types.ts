export interface InputItem {
  name: string;
  img: string;
  subImage?: string;
  value?: string;
  placeholder?: string;
  imgCursor?: string;
  error?: string;
  errorBorder?: string;
  validation: boolean;
  title?: string;
  withImage?: boolean;
  height?: string;
  width?: string;
  onChange?: (value: string) => void;
}
