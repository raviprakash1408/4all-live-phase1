export const ProfileItems = [
  { id: '1', name: 'Kavana', url: '' },
  { id: '2', name: 'Lakshmi', url: '' },
  { id: '3', name: 'Unnathi', url: '' },
  { id: '4', name: 'John', url: '' },
  { id: '5', name: 'Unn', url: '' },
  { id: '6', name: 'Romero', url: '' },
  { id: '7', name: 'Unnat', url: '' },
  { id: '8', name: 'John Romero', url: '' },
];
