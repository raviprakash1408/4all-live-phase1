interface ProfileItem {
  id: string;
  url?: string;
  name?: string;
}

export interface MemberPic {
  ProfileItems?: ProfileItem[];
}
