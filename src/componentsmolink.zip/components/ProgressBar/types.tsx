export interface RadialProgressBarTypes {
  progress: number;
  radius: number;
  // percent: number;
}
