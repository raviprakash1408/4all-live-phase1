import RadialProgressBar from '.';

export default {
  component: RadialProgressBar,
  title: 'RadialProgressBar',
  tags: ['RadialProgressBar'],
};

export const Default = () => <RadialProgressBar progress={100} radius={40} />;
