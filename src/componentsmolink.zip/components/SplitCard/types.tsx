export interface SplitCardType {
  range: boolean;
}
