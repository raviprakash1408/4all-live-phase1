export interface NewTaskTypes {
  props: string;
  title: string;
  position: string;
  width: string;
  img: string;
}
