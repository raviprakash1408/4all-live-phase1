import React from 'react';

import type { NewTaskTypes } from './types';

const Temporary = (New: NewTaskTypes) => {
  return (
    <div>
      {' '}
      <div>
        <div className="relative mt-6 flex h-11 flex-col">
          <span className="pointer-events-none absolute bottom-8 ml-4 flex-1  bg-primary-color p-1 text-sm  text-quaternary-color">
            {New.props}
          </span>
          <div
            data-testid="inputField"
            // type="text"
            className={`pt-2 text-quaternary-color ${New.width} flex-1 rounded-full border-2 border-solid border-tertiary-color
         bg-primary-color
        pl-12 pr-2 text-base font-thin  transition-colors  duration-300 ease-in-out placeholder:text-quaternary-color  
       
       
            hover:border-quaternary-color
        focus:outline-none`}
          >
            {New.title}
          </div>

          <img
            src={New.img}
            className={`absolute ${New.position} ml-4 mt-[10px] h-6 w-6 `}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default Temporary;
