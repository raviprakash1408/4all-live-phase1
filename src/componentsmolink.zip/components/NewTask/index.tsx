'use client';

import React, { useState } from 'react';

import { CustomizedSelect } from '../CustomizedSelect';
import { HalfCurvedButtons } from '../halfcurvedbuttons';
import Toggle from '../toggle button/toggle';
import Temporary from './temporary';

const CreateTask = () => {
  const [popup, setPopup] = useState(false);

  return (
    <div>
      <button
        type="button"
        onClick={() => {
          setPopup(!popup);
        }}
        className="ml-8 mt-4"
      >
        <HalfCurvedButtons
          content="New Live Feed"
          image="/assets/icons/icon10.svg"
          backgroundColor="bg-tertiary-color"
          halfCurved={false}
          Color=""
          Color1=""
        />
      </button>
      {popup && (
        <div>
          <div className="custom-bg-color absolute bottom-0  left-0 z-10 h-[99.7%] w-full">
            <div className=" absolute left-[37%] top-[26%]">
              <div className="h-[29rem] w-[39rem] overflow-y-auto bg-primary-color sm:rounded-2xl">
                <h1 className="mt-4 text-center text-sm text-font-color">
                  Create new task
                </h1>
                <button
                  type="button"
                  onClick={() => {
                    setPopup(false);
                  }}
                >
                  <img
                    src="/assets/icons/close.svg"
                    alt=""
                    className="absolute right-0 top-0"
                  />
                </button>
                <div className="ml-6 flex">
                  <Toggle />
                  <div className="ml-2 flex">
                    <Toggle />
                    <span className="ml-2 text-sm ">Always recording</span>
                  </div>
                </div>
                <div className="ml-1.5 grid grid-cols-2 gap-1 ">
                  <div>
                    <Temporary
                      props="Start Date"
                      title="29/12/2023 - 11:30PM"
                      width="w-72"
                      img="/assets/icons/calender.svg"
                      position="right-[30px]"
                    />
                  </div>
                  <div>
                    <Temporary
                      props="End Date"
                      title="20/012/2023 - 11:30PM"
                      width="w-72"
                      img="/assets/icons/calender.svg"
                      position="right-[30px]"
                    />
                  </div>
                </div>
                <div className="ml-12">
                  <Temporary
                    props="Time zone"
                    title="GMT -5:00 Central Standard Time"
                    width="w-[32rem]"
                    img="/assets/icons/timezone.svg"
                    position=""
                  />
                </div>
                <div className="mt-5 ">
                  <span className="ml-5 text-sm font-semibold text-quaternary-color">
                    Live Feeds
                  </span>
                  <div className="ml-[15px]">
                    <CustomizedSelect
                      width="w-[36rem]"
                      height="h-10"
                      arrowBottom="top-[14px]"
                      border="rounded-full"
                    />
                  </div>
                </div>
                <hr className="ml-[26px] mt-12 w-[90%] border border-tertiary-color" />
                <div>
                  <div className="ml-[7.5rem] mt-6 flex flex-row">
                    <Toggle />
                    <span className="ml-2 text-sm">
                      Send email notification
                    </span>
                    <button
                      type="button"
                      className="ml-5 h-10 w-36 rounded-3xl bg-secondary-color text-center text-font-color no-underline"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateTask;
