export interface CheckBoxTypes {
  // name: string;
  // img: string;
  // subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  backgroundColor: string;
}
