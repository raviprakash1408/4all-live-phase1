'use client';

import React, { useState } from 'react';

import type { CheckBoxTypes } from './types';

const Checkbox = (props: CheckBoxTypes) => {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
  };

  return (
    <label
      htmlFor="chekcbox"
      className="flex cursor-pointer items-center space-x-2"
    >
      <input
        type="checkbox"
        className="hidden"
        checked={isChecked}
        id="chekcbox"
        onChange={handleCheckboxChange}
      />
      <span
        className={`flex h-5 w-5 items-center justify-center rounded border-2 border-solid border-quaternary-color ${props.backgroundColor} `}
      >
        {isChecked && <span className="h-2 w-2 bg-secondary-color" />}
      </span>
    </label>
  );
};

export default Checkbox;
