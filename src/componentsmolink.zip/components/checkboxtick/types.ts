export interface CheckBoxTickTypes {
  // name: string;
  // img: string;
  // subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  backgroundColor: string;
  secondaryColor?: string;
  tickColor?: string;
}
