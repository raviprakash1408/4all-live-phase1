export interface ArrowTypes {
  // name: string;
  // img: string;
  // subImage?: string;
  // type: 'normal' | 'logo' | 'team';
  // url: string;
  backgroundColor: string;
  rotate: string;
  width: string;
  img: string;
  onClick?: () => void;
}
