import type { SpaceGridType } from './type';

export default {
  component: 'SpaceGrid',
  title: 'SpaceGrid',
  tags: ['SpaceGrid'],
};

export const Default: { args: SpaceGridType } = {
  args: {
    height: 'h-48',
    width: 'w-96',
    CameraName: 'Camera 01',
    content2: '',
    id: '01',
  },
};
