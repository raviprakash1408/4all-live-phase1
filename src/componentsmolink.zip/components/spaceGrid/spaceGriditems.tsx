export const SpaceGridsarray = [
  {
    id: 1,
    CameraName: 'Camera 01',
    img: '/assets/images/spaceship.png',
  },
  {
    id: 2,
    CameraName: 'Camera 02',
    img: '/assets/images/spaceship.png',
  },
  {
    id: 3,
    CameraName: 'Camera 03',
    img: '/assets/images/spaceship.png',
  },
  {
    id: 4,
    CameraName: 'Camera 04',
    img: '/assets/images/spaceship.png',
  },
  {
    id: 5,
    CameraName: 'Camera 05',
    img: '/assets/images/spaceship.png',
  },
];
