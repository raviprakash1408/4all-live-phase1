export interface SpaceGridType {
  spaceGridItems: any;
  height: string;
  width: string;
  content: string;
  content2?: string;
  id: string;
  CameraName?: string;
  img?: string;
}
export interface Camera {
  SpaceGridsarray?: SpaceGridType[];
}
