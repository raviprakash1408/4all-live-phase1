import { useState } from 'react';

import CheckboxTick from '../checkboxtick';
import type { SpaceGridType } from './type';

const SpaceGrid = (props: SpaceGridType) => {
  const SpaceGridsarray = props;
  const [selected, setSelected] = useState(false);

  return (
    <div>
      <button
        type="button"
        onClick={() => {
          setSelected(!selected);
        }}
        className=" relative w-96 pl-5 pt-10"
      >
        <img
          src="/assets/images/spaceship.png"
          alt=""
          className={`${props.height} ${
            props.width
          }  rounded-2xl border-2  hover:border-secondary-color ${
            selected ? 'border-secondary-color' : 'border-primary-color'
          }`}
        />
        <img
          src="/assets/icons/Zoomout.svg"
          alt=""
          className=" absolute bottom-1 left-[17.2rem] ml-20 w-6 rounded-lg bg-tertiary-color p-1"
        />
        <div className="absolute top-12 ml-4 flex h-8 w-40 items-center rounded-lg bg-tertiary-color">
          {selected && (
            <div>
              <div>
                <CheckboxTick
                  backgroundColor="bg-transparent"
                  secondaryColor="text-secondary-color"
                />
              </div>
              <div className="absolute  left-64 top-1 flex h-6 w-20 items-center rounded-2xl bg-tertiary-color px-2">
                <div className=" h-2 w-2 rounded-full bg-[#FF1759] px-1 " />
                <div className="px-4 text-[#E1E7EA]">Live</div>
              </div>
            </div>
          )}
          <img src="/assets/icons/Video.svg" className="ml-2 mt-0 h-5" alt="" />
          <div className=" ml-2 flex items-center  rounded-xl text-base text-font-color">
            {props.CameraName}{' '}
            <span className="ml-2 items-center text-base text-quaternary-color">
              {props.content2}
            </span>{' '}
          </div>
        </div>
      </button>
    </div>
  );
};

export default SpaceGrid;
