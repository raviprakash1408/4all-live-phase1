import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React from 'react';

import type { MenuItem } from './types';

const SidebarMenuItem = ({
  item,
  showMenu,
}: {
  item: MenuItem;
  showMenu: boolean;
}) => {
  // get current url using next js router
  const pathname = usePathname() || '';
  const isActive = pathname.includes(item.url);

  const getData = () => {
    let data: JSX.Element;
    switch (item.type) {
      case 'logo':
        data = (
          <div className="flex items-center justify-center gap-[10px] py-[22px]">
            <img className="shrink-0" src={item.img} alt="logo" />
            <img
              className={`shrink-0 ${!showMenu && 'hidden'}`}
              src={item.subImage}
              alt="logo2"
            />
          </div>
        );

        break;
      case 'team':
        data = (
          <div className="mb-2.5 flex items-center bg-primary-color duration-300">
            <div className="relative shrink-0">
              <img src={item.img} className="py-2.5 pl-5 pr-3" alt="team" />
              <div
                className={`absolute bottom-1 right-1 flex h-7 w-7 items-center justify-center rounded-full bg-secondary-color duration-300 ${
                  showMenu && 'hidden'
                }`}
              >
                <img
                  className="brightness-0 invert"
                  src={item.subImage}
                  alt="switch_team"
                />
              </div>
            </div>

            <div
              className={`${!showMenu && 'hidden'} shrink-0 pr-2 duration-300`}
            >
              <p
                className={`threeDotText w-36 text-base text-quaternary-color ${
                  !showMenu && 'hidden'
                }`}
              >
                Sony pictures Television
              </p>
              <div
                className={`flex w-36 justify-center rounded-[52px] bg-quaternary-color px-2.5${
                  !showMenu && 'hidden'
                }`}
              >
                <p className="pr-3">Switch team</p>
                <img src={item.subImage} alt="switch_team" />
              </div>
            </div>
          </div>
        );
        break;
      default:
        data = (
          <Link href={item.url}>
            <div className="group flex cursor-pointer items-center pr-[5px]  hover:bg-primary-color">
              <div
                className={`mr-4 h-[70px] w-[5px] shrink-0 rounded-[3px] ${
                  isActive
                    ? 'bg-secondary-color'
                    : 'bg-tertiary-color group-hover:bg-primary-color'
                } `}
              />
              <div
                className={`${
                  isActive &&
                  'bg-secondary-color group-hover:!bg-secondary-color'
                } flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full bg-primary-color group-hover:bg-quaternary-color`}
              >
                <img
                  className={`${
                    isActive && 'brightness-0 invert'
                  }   ease-in-out group-hover:brightness-0 group-hover:invert`}
                  src={item.img}
                  alt={item.name}
                />
              </div>
              <p
                className={`sidebarName shrink-0 pl-2.5 text-quaternary-color duration-300 ${
                  !showMenu && 'hidden'
                }`}
              >
                {item.name}
                {/* {item.url} */}
              </p>
            </div>
          </Link>
        );
    }

    return data;
  };
  return getData();
};

export default SidebarMenuItem;
