// component name: Sidebar

'use client';

import React, { useState } from 'react';

import SidebarMenuItem from './sidebarMenuItem';
import type { MenuItem } from './types';

const Sidebar = ({
  sidebarMenuItems,
}: {
  sidebarMenuItems: Array<MenuItem>;
}) => {
  const [showMenu, setShowMenu] = useState<boolean>(true);

  return (
    // <div className="flex">
    <div
      className={`bg-tertiary-color ${
        showMenu ? 'w-60' : 'w-24'
      }  relative duration-300`}
      // style={{ transition: 'width 300ms cubic-bezier(0.2, 0, 0, 1) 0s' }}
    >
      {sidebarMenuItems.map((item) => {
        return (
          <SidebarMenuItem key={item.name} item={item} showMenu={showMenu} />
        );
      })}
      <button
        type="button"
        className="group absolute -right-[1.6rem] top-1/2 flex h-20 -translate-x-1/2 -translate-y-1/2 cursor-pointer items-center self-center rounded-r-[20px] bg-tertiary-color pl-[3px] pr-2 transition duration-150 ease-out hover:bg-fifth-color hover:ease-in "
        onClick={() => setShowMenu((preValue) => !preValue)}
      >
        <img
          className={`${
            !showMenu ? 'rotate-180' : ''
          } duration-300 ease-in-out group-hover:translate-x-0.5`}
          src="/assets/icons/arrow-close.svg"
          alt=""
        />
      </button>
    </div>

    // </div>
  );
};

export { Sidebar };
