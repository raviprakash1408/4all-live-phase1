import CommonButton from '.';

export default {
  component: CommonButton,
  title: 'CommonButton',
  tags: ['CommonButton'],
};

export const Default = () => (
  <CommonButton name="Join Space" img="/assets/icons/Group 914.png" />
);
