'use client';

import React, { useState } from 'react';

import type { DemoButton } from './types';

const CurvedButton = (props: DemoButton) => {
  const [clicked, setClicked] = useState(false);

  const curve = () => {
    if (!props.halfCurved) return 'rounded-full';
    if (props.curveType === 'left') return 'rounded-l-full';
    return 'rounded-r-full';
  };

  const handleClick = () => {
    setClicked(!clicked);
  };

  return (
    <button
      type="button"
      className={`group flex w-full ${curve()} items-center justify-center border-2 border-tertiary-color ${
        clicked ? 'bg-secondary-color' : props.backgroundColor
      }`}
      onClick={handleClick}
    >
      {props.children}
    </button>
  );
};

export { CurvedButton };
