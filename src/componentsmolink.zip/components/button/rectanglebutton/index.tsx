import React from 'react';

import type { MenuItem } from './types';

const RectangleButton = (props: MenuItem) => {
  const curve = () => {
    if (!props.topCurved) return '';
    if (props.curveType === 'left') return 'rounded-tl-3xl';
    if (props.curveType === 'right') return 'rounded-tr-3xl';
    return 'rounded-t-2xl';
  };
  const { height, width } = props;

  return (
    <div
      className={` ml-4  flex ${height} ${width} items-center ${curve()} border-2 border-tertiary-color ${
        props.backgroundColor
      }  ${props.Color} hover:border-quaternary-color`}
    >
      <img src={props.img} alt="Icon" className="ml-2" />
      <div className=" ml-4 text-sm">{props.content}</div>
    </div>
  );
};

export { RectangleButton };
