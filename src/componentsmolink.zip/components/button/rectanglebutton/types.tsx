export interface MenuItem {
  img: string;
  subImage?: string;
  backgroundColor: string;
  content: string;
  Color: string;
  Color1: string;
  topCurved?: boolean;
  curveType?: 'left' | 'right' | 'both';
  height: string;
  width: string;
}
