import React, { useReducer } from 'react';

import { CustomizedSelect } from '../CustomizedSelect';
import InputField from '../input field/InputField';
import SelectInputField from '../SelectInputField';
import type { LiveSettings } from './types';

const fields: LiveSettings[] = [
  {
    name: 'Namer',
    key: 'name',
    input_type: 'text',
    value: 'Camera01',
    key_word: 'namefield',
  },
  {
    name: 'Preset',
    key: 'preset',
    input_type: 'select',
    options: ['Production', 'Private'],
    value: 'Production',
    key_word: 'productionfield',
  },
  {
    name: 'Input',
    key: 'Input',
    input_type: 'dropdown',
    options: ['Public', 'Private'],
    value: 'Public',
    key_word: 'inputfield',
  },
  {
    name: 'Preview',
    key: 'Preview',
    input_type: 'dropdown',
    options: ['Public', 'Private'],
    value: 'Public',
    key_word: 'Previewfield',
  },

  {
    name: 'Output',
    key: 'Output',
    input_type: 'dropdown',
    options: ['Public', 'Private'],
    value: 'Public',
    key_word: 'outputfield',
  },
];

const reducer = (
  state: LiveSettings[],
  action: { type: 'UPDATE_FIELD_VALUE'; value: string; key: string }
) => {
  switch (action.type) {
    case 'UPDATE_FIELD_VALUE': {
      if (Array.isArray(state)) {
        const newState = state.map((item) => {
          const newItem = item;
          if (item.key === action.key) {
            newItem.value = action.value;
          }
          console.log(newItem, 'newItem');
          return newItem;
        });

        return { ...newState };
      }

      return state;
    }
    // case 'RESET':
    //   return state;

    default:
      return state;
  }
};

const LivefeedForm = () => {
  const [fieldValues, dispatchFieldValues] = useReducer(reducer, fields);
  console.log(fieldValues, 'fieldValues');

  const livefeedfun = (field: {
    input_type?: any;
    name?: any;
    value?: any;
    key?: any;
  }) => {
    const { name, value, key } = field;

    // const value = Array.isArray(fieldValues)
    //   ? fieldValues?.find((ite) => ite.key === field.key)?.value
    //   : undefined;

    // value = value === undefined ? (item[field.key] as string) : value;

    switch (field.input_type) {
      case 'select':
        return (
          // <div className="-mt-16 ml-72 flex">
          <CustomizedSelect
            width="w-[16vw]"
            height="h-[4vh]"
            title={name}
            border="rounded-full"
            arrowBottom="top-[12px]"
            textcolor="text-font-color"
          />
          // </div>
        );

      case 'dropdown':
        return (
          // <div className="flex">
          <div className="ml-4 mt-8 flex-row">
            <SelectInputField
              title={name}
              width="w-[25vw]"
              MarginTop="mt-[0.4vh]"
            />
          </div>
          // </div>
        );

      default:
        return (
          // <div className="flex">
          <InputField
            name={name}
            validation
            withImage={false}
            height="h-[4.2vh]"
            width="w-[12vw]"
            value={value}
            img="" // onChange={(e: ChangeEvent<HTMLInputElement>) => {
            //   dispatchFieldValues({
            //     type: 'UPDATE_FIELD_VALUE',
            //     value: e.target.value,
            //     key,
            //   });
            // }}
          />
          // </div>
        );
    }
  };

  return (
    <div className="custom-scrollbar mt-5 h-[35vh] w-[81vw] overflow-y-auto overflow-x-hidden md:max-md:w-[84vw]">
      <div className="flex">
        {fields.slice(0, 2).map((field, index) => {
          const result = livefeedfun(field);
          return index !== 1 ? (
            <>{result} &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</>
          ) : (
            result
          );
        })}
        <div className="mt-4 flex">
          {fields.slice(2, 4).map((field, index) => {
            const result = livefeedfun(field);
            return index !== 1 ? (
              <>
                {result} &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
              </>
            ) : (
              result
            );
          })}
        </div>

        {/* <div className="flex">
                      key,
         
          <InputField
            name="Name"
            enableBlur
            withImage={false}
            height="h-[4.2vh]"
            width="w-[12vw]"
            bottominput="bottom-6"
          />

          <div className="mt-5">
            <CustomizedSelect
              width="w-[16vw]"
              height="h-[4vh]"
              title="Preset"
              border="rounded-full"
              arrowBottom="top-[12px]"
              textcolor="text-font-color"
            />
          </div>
        </div> */}
        {/* <div className="ml-6 flex">
          <div>
            <Input
              title="Input"
              width="w-[29vw]"
              MarginTop="mt-[0.4vh]"
              value="Initial Value"
            />
          </div>
          <div className="ml-7">
            <Input title="Preview" width="w-[25vw]" MarginTop="mt-[0.4vh]" />
          </div>
          <div className="ml-6 mt-1">
            <CurvedButton backgroundColor="bg-tertiary-color" height="h-[10vw]">
              <div className="flex px-[1vw] py-[0.5vh]">
                <img
                  src="/assets/icons/icon16.svg "
                  alt=""
                  className="h-5 w-5"
                />
                <div className="px-[1vw]  text-sm text-quaternary-color group-hover:text-secondary-color">
                  check
                </div>
              </div>
            </CurvedButton>
          </div>
          <div className="ml-4 mt-4 h-4 w-4">
            <img src="/assets/icons/icon24.svg" alt="" />
          </div>
          <div className="-mt-3 ml-2">
            <p className=" text-sm text-quaternary-color">Connection found!</p>
          </div>
        </div>
        <div className="ml-3 mt-3 flex">
          <div className="ml-4">
            <Input title="output" width="w-[29vw]" MarginTop="mt-1" />
          </div>
          <div className="ml-2 mt-0">
            <SettingsComponent
              content="Add output"
              height="h-[4vh]"
              width="w-[10vw]"
              backgroundColor="bg-tertiary-color"
              image="/assets/icons/icon17.svg"
              textcolor="text-quaternary-color"
              textsize="text-sm"
              hoverColor="hover:border-quaternary-color"
            />
          </div>
          <div className="ml-2 mt-0">
            <SettingsComponent
              content="Schedule"
              height="h-[4vh]"
              width="w-[10vw]"
              backgroundColor="bg-tertiary-color"
              image="/assets/icons/icon18.svg"
              textcolor="text-quaternary-color"
              textsize="text-sm"
              hoverColor="hover:border-quaternary-color"
            />
          </div>
        </div>
        <div
          className="mx-4 -ml-1 mt-6 border-t-2 border-t-tertiary-color
          "
        >
          <div className=" ml-6 mt-4 flex">
            <div className=" -mr-1 ml-2 mt-1">
              <CurvedButton
                backgroundColor="bg-primary-color"
                height="h-[8vh]"
                halfCurved
                curveType="left"
              >
                <div className="flex px-[1vw] py-[0.5vh] ">
                  <img src="/assets/icons/icon19.svg " alt="" />
                  <div className="px-[2vw] text-sm text-quaternary-color group-hover:text-quaternary-color">
                    Format
                  </div>
                </div>
              </CurvedButton>
            </div>
            <div className="ml-1 mt-1">
              <FileComponent
                height="h-[4vh]"
                backgroundcolor="bg-teritary-color"
                topCurved={false}
              >
                <div className="flex items-center px-[1vw]">
                  <img src="/assets/icons/icon20.svg" alt="" />
                </div>
                <div className="px-[2vw] text-sm">Video</div>
              </FileComponent>
            </div>
            <div className="ml-0 mt-1">
              <FileComponent
                height="h-[4vh]"
                backgroundcolor="bg-teritary-color"
                topCurved={false}
              >
                <div className="flex items-center px-[1vw]">
                  <img src="/assets/icons/Groupaudio.svg" alt="" />
                </div>
                <div className="px-[2vw] text-sm">Audio</div>
              </FileComponent>
            </div>
            <div className="-mr-4  mt-1">
              <FileComponent
                height="h-[4vh]"
                backgroundcolor="bg-teritary-color"
                topCurved={false}
              >
                <div className="flex items-center px-[1vw]">
                  <img src="/assets/icons/icon22.svg" alt="" />
                </div>
                <div className="px-[2vw] text-sm">Filters</div>
              </FileComponent>
            </div>
            <div className="ml-4 mt-1">
              <CurvedButton
                backgroundColor="bg-primary-color"
                height="h-[8vh]"
                halfCurved
                curveType="right"
              >
                <div className="flex items-center px-[1vw] py-[0.5vh]">
                  <img src="/assets/icons/icon23.svg " alt="" />
                  <div className="px-[2vw] text-sm text-quaternary-color group-hover:text-secondary-color">
                    Options
                  </div>
                </div>
              </CurvedButton>
            </div>
          </div>
          <div className="ml-6 mt-8  flex">
            <div className="ml-4">
              <CustomizedSelect
                width="w-[12vw]"
                height="h-[4vh]"
                title="Codec"
                border="rounded-full"
                textcolor="text-font-color"
              />
            </div>
            <div className="ml-4">
              <CustomizedSelect
                width="w-[12vw]"
                height="h-[4vh]"
                title="Channel"
                border="rounded-full"
                textcolor="text-font-color"
              />
            </div>
            <div className="ml-4">
              <CustomizedSelect
                width="w-[12vw]"
                height="h-[4vh]"
                title="Quality"
                border="rounded-full"
                textcolor="text-font-color"
              />
            </div>
            <div className="ml-4">
              <CustomizedSelect
                width="w-[12vw]"
                height="h-[4vh]"
                title="Sample rate"
                border="rounded-full"
                textcolor="text-font-color"
              />
            </div>
            <div className="absolute bottom-[20vh] right-[50vh] text-base text-quaternary-color">
              volume
            </div>
            <div className="absolute bottom-[20vh] right-[35vh] text-base text-quaternary-color">
              32db
            </div>
            <div className="ml-4 mt-5">
              <RangeSlider
                progress={40}
                type="thumbBorder"
                width="w-48"
                textSide=""
                dataType=""
              />
            </div>
          </div>
        </div> */}
      </div>
    </div>
  );
};

export default LivefeedForm;
