export interface LiveSettings {
  name: string;
  key: string;
  input_type: string;
  options?: string[];
  value?: string;
  key_word?: string;
}
