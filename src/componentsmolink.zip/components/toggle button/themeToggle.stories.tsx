import ThemeToggle from './themeToggle';

export default {
  component: ThemeToggle,
  title: 'ThemeToggle',
  tags: ['ThemeToggle'],
};

export const Default = () => <ThemeToggle />;
