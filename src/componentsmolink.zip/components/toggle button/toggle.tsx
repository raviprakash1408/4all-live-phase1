'use client';

import { useState } from 'react';

const Toggle = ({ label }: { label?: boolean }) => {
  const [isChecked, setIsChecked] = useState(false);

  const handleToggle = () => {
    setIsChecked(!isChecked);
  };

  return (
    <div>
      <label
        htmlFor="toggle"
        className="relative inline-flex cursor-pointer items-center"
      >
        <input
          onClick={handleToggle}
          type="checkbox"
          value=""
          id="toggle"
          className="peer sr-only"
        />
        <div className="h-6 w-11 rounded-full border-2  border-solid border-quaternary-color  after:absolute  after:left-[6px] after:top-[4px] after:h-4 after:w-4 after:rounded-full after:bg-quaternary-color after:transition-all after:content-[''] peer-checked:border-none peer-checked:bg-secondary-color peer-checked:after:translate-x-full peer-checked:after:border-none peer-checked:after:bg-white peer-focus:outline-none  dark:bg-primary-color dark:after:bg-quaternary-color" />

        <div className="absolute">
          {isChecked && (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="white"
              className="m-auto ml-1 h-4 w-4"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          )}
        </div>
        {label && (
          <label
            htmlFor="toggle"
            className="ml-2 text-sm text-quaternary-color"
          >
            {isChecked ? 'Enabled' : 'Disabled'}
          </label>
        )}
      </label>
    </div>
  );
};

export default Toggle;
