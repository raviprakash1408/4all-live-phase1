import Toggle from './toggle';

export default {
  component: Toggle,
  title: 'Toggle',
  tags: ['Toggle'],
};

export const Default = () => <Toggle />;
