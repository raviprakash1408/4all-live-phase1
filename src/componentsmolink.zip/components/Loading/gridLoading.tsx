import React from 'react';

const GridLoading = () => {
  return (
    <div>
      <div className="relative mt-4 h-20 w-full animate-pulse rounded bg-tertiary-color" />
    </div>
  );
};

export default GridLoading;
