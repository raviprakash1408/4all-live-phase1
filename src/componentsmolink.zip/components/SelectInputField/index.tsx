import React from 'react';

import { CustomizedSelect } from '../CustomizedSelect';
import type { InputAndOutputTypes } from './types';

const SelectInputField = (props: InputAndOutputTypes) => {
  return (
    <div>
      <div className=" group flex w-60 flex-row">
        <CustomizedSelect
          title={props.title}
          width="w-[5rem]"
          // data={SelectOptions}
          height="h-10"
          borderLeft="rounded-l-full"
          arrowBottom="bottom-[41.5%]"
          borderRight="border-r-0"
        />
        <input
          data-testid="inputField"
          type="text"
          className={`${props.MarginTop}  h-10 ${props.width} rounded-r-full border-2 border-solid 
          border-tertiary-color
         bg-primary-color px-2 font-thin text-font-color transition-colors duration-300  ease-in-out placeholder:text-quaternary-color focus:outline-none  
         
             group-hover:border-quaternary-color`}
        />
      </div>
    </div>
  );
};

export default SelectInputField;
