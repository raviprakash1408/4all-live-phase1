export interface InputAndOutputTypes {
  MarginTop?: string;
  title: string;
  width: string;
}
