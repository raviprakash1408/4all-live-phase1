import SelectInputField from '.';

export default {
  component: SelectInputField,
  title: 'SelectInputField',
  tags: ['SelectInputField'],
};

export const Default = () => <SelectInputField title="Input" width="w-48" />;
