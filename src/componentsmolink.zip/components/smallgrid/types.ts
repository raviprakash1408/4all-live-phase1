export interface SmallGridItems {
  img: string;
  subImage: string;
  backgroundColor: string;
  content1: string;
  content2: string;
  content3: string;
  height: string;
  width: string;
}
