import React from 'react';

import type { SmallGridItems } from './types';

const SmallGrid = (props: SmallGridItems) => {
  return (
    <div
      className={` group rounded-3xl   p-4 ${props.backgroundColor} ${props.height} ${props.width} hover:bg-secondary-color`}
    >
      <div className="flex h-20  w-32 flex-col">
        <div className="flex">
          <img src={props.img} alt="1" className="" />

          <div className="ml-2 flex-col">
            <div className="text-quaternary-color group-hover:text-font-color">
              {props.content1}
            </div>
            <div className="text-quaternary-color group-hover:text-font-color">
              {props.content2}
            </div>
          </div>
        </div>
        <div className="mt-4 flex justify-between">
          <div className="flex ">
            <img src={props.subImage} alt="no" className="" />
          </div>
          <div>2</div>
          <div className="text-quaternary-color group-hover:text-font-color">
            {props.content3}
          </div>
        </div>
      </div>
    </div>
  );
};

export { SmallGrid };
