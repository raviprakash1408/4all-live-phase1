export interface Gridbar {
  backgroundColor: string;
  BackgroundColor: string;
  FontColor: string;
  img: string;
  title: string;
  content: string;
  size?: 'small' | 'medium' | 'large';
}
