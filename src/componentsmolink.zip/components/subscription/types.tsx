export interface SubscriptionType {
  id: number;
  plan_name: string;
  price: number;
  button_text: string;
  img: string;
}
