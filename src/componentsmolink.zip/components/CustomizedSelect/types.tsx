export interface SelectTypes1 {
  title?: string;
  img?: string;
  width: string;
  height: string;
  borderLeft?: string;
  borderRight?: string;
  border?: string;
  data?: string[] | number[];
  arrowBottom?: string;
  textcolor?: string;
}
