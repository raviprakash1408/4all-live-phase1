'use client';

import React, { useState } from 'react';

import type { SelectTypes1 } from './types';

const CustomizedSelect = (props: SelectTypes1) => {
  const [value, setValue] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string>('');
  // const Accor = {
  //   id: 1,
  //   title: 'SDI',
  //   child: 'Sony Camera',
  //   img: '/assets/icons/Camera.svg',
  // };

  const options = [
    { id: 1, name: 'A' },
    { id: 2, name: 'B' },
    { id: 3, name: 'C' },
    { id: 4, name: 'D' },
    { id: 5, name: 'E' },
    { id: 6, name: 'RTSP' },
  ];

  return (
    <div>
      <button
        type="button"
        data-testid="CustomizedSelect"
        onClick={() => {
          setValue(!value);
        }}
        className={`relative ${props.height} ${props.width} ${props.border} ${props.borderLeft} ${props.borderRight} border-2 border-tertiary-color duration-300 ease-in-out group-hover:border-quaternary-color`}
      >
        <span className="pointer-events-none absolute  bottom-[64%] left-[19%]   bg-primary-color p-1 text-sm  text-quaternary-color">
          {props.title}
        </span>
        <div className="flex">
          <img src={props.img} alt="" className="ml-2" />
          <span className=" z-10 ml-2 text-quaternary-color">
            {selectedOption}
          </span>
        </div>
        <div className="flex justify-end">
          <img
            src="/assets/icons/Vector (3).png"
            alt="Icon"
            className={`absolute ${props.arrowBottom} mr-2 w-3 ${
              value ? 'rotate-180' : ''
            }`}
          />
        </div>
      </button>
      <div
        className={`${props.width} absolute z-10 ${
          value
            ? '  rounded-lg border-2 border-t-0  border-solid  border-tertiary-color bg-fifth-color '
            : ''
        }`}
      >
        {options.map((item) => (
          <div key={item.id}>
            {value && (
              <div>
                <div className="flex flex-col">
                  <button
                    type="button"
                    onClick={() => setSelectedOption(item.name)}
                    className="h-[34px] cursor-pointer  text-base text-quaternary-color hover:bg-tertiary-color"
                  >
                    {item.name}
                  </button>
                  <hr className="border-solid border-tertiary-color" />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export { CustomizedSelect };
